package br.com.scrumming.web.infra;

public final class PaginasUtil {

    public final class Geral {
        public static final String LOGIN_PAGE = "/paginas/login.xhtml";
        public static final String BENVINDO_PAGE = "/paginas/bemvindo.xhtml";
    }
}
