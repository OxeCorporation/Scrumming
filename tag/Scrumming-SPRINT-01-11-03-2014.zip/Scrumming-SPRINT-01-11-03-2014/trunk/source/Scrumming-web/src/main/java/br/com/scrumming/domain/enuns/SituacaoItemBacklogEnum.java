package br.com.scrumming.domain.enuns;

public enum SituacaoItemBacklogEnum {
    FAZER, FAZENDO, FEITO;
}
