package br.com.scrumming.domain.enuns;

public enum SituacaoSprintEnum {
	ABERTA, CONCLUIDA, FECHADA;
}