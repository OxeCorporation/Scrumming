package br.com.scrumming.domain.enuns;

public enum SituacaoTarefaEnum {
	PARA_FAZER, FAZENDO, FEITO, CANCELADO, EM_IMPEDIMENTO;
}
