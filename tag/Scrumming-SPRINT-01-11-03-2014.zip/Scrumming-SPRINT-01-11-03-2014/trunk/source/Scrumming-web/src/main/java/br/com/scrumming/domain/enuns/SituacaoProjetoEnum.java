package br.com.scrumming.domain.enuns;

public enum SituacaoProjetoEnum {
	ATIVO, INATIVO, CANCELADO;
}