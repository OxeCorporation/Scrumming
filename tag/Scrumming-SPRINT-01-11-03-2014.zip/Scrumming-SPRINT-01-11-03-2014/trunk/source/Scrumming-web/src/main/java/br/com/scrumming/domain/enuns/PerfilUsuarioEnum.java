package br.com.scrumming.domain.enuns;

public enum PerfilUsuarioEnum {
	PRODUCT_OWNER, SCRUM_MASTER, TEAM;
}
