package br.com.scrumming.core.infra.repositorio;

public class HibernateTypes {

	 // Joda time
    public static final String JODA_LOCAL_DATE =
            "org.jadira.usertype.dateandtime.joda.PersistentLocalDate";
    public static final String JODA_DATE_TIME =
            "org.jadira.usertype.dateandtime.joda.PersistentDateTime";
}
